/* global sc */

// This script is called at the end of the installation
// set execute access for shell scripts

let ExecuteProcess = Packages.agorum.commons.utils.ExecuteProcess;
let path = Packages.agorum.commons.jboss.JBossPathUtil.getServerHomePath() + '/deploy/roi.ear/documentservice/scripts';

let ep = new ExecuteProcess();
ep.execute(['/bin/sh', '-c', 'chmod 700 *.sh' ], path, true);
