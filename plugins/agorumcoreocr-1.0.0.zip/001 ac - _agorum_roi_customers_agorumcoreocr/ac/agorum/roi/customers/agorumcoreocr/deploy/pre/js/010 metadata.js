/* global sc */

let mb = require('/agorum/roi/customers/Standard/js/metadata-builder');
let yaml = require('common/objects').find('/agorum/roi/customers/agorumcoreocr/yml/metadata.yml');

mb(yaml).install(sc);