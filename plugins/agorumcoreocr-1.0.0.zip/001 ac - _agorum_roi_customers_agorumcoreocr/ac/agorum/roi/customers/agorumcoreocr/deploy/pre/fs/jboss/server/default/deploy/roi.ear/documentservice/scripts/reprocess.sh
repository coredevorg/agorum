#/bin/sh

UUID=$(cat /proc/sys/kernel/random/uuid)

tmpDir=/tmp/ocr/${UUID}
mkdir -p ${tmpDir}

BASEDIR=$(dirname $0)
cd ${BASEDIR}/../../../../../../../ocr/bin

export WINEDEBUG=-all
wine ReadIRISOCRConverter.exe reprocessing ${tmpDir}/out.txt
LANG=C.UTF-8
cp ${tmpDir}/out.txt /tmp/out.txt
cat ${tmpDir}/out.txt

rm -Rf ${tmpDir}
