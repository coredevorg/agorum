let objects = require('common/objects');

let adminFolder = objects.find('/home/roi/MyFiles').createPath('Administration');

if (!adminFolder.getItem('customers')) {
  adminFolder.add(objects.find('/agorum/roi/customers'));
}

if (!adminFolder.getItem('Scripting')) {
  adminFolder.add(objects.find('/agorum/roi/Scripting'));
}

if (!adminFolder.getItem('workspace')) {
  let f = objects.tryFind('/agorum/roi/workspace');
  if (f) {
    // is only linked, when existing
    adminFolder.add(f);
  }
}
