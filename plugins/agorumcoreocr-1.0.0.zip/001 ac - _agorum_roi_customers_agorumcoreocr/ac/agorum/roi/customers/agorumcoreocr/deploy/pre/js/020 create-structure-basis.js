/* global sc */

global.sessionControllerAdmin = sc;

let objects = require('common/objects');
let sb = require('/agorum/roi/customers/Standard/js/structure-builder');
let yamlbasis = objects.find('/agorum/roi/customers/agorumcoreocr/yml/structure-basis.yml');

sb(yamlbasis).create();

// ATTENTION: when using true, everything is set newly, should only be used for testing
// sb(yamlbasis, true).create();