#/bin/sh
UUID=$(cat /proc/sys/kernel/random/uuid)

tmpDir=/tmp/ocr/${UUID}
mkdir -p ${tmpDir}

convert $1 -density 300 -type truecolor ${tmpDir}/ocr[%d].jpg
shift

BASEDIR=$(dirname $0)
cd ${BASEDIR}/../../../../../../../ocr/bin

export WINEDEBUG=-all
wine ReadIRISOCRConverter.exe ${tmpDir} "$@"

rm -Rf ${tmpDir}
