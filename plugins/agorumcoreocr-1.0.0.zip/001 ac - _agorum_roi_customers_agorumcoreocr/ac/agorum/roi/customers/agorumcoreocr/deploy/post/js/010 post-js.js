/* global sc */

// This script is called at the end of the installation
