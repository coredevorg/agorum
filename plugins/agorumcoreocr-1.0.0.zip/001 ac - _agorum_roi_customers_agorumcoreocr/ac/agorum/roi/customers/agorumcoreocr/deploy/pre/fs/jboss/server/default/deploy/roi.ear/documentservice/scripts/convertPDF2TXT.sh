#/bin/sh
UUID=$(cat /proc/sys/kernel/random/uuid)

tmpDir=/tmp/ocr/${UUID}
mkdir -p ${tmpDir}

mv $1 ${tmpDir}
shift

BASEDIR=$(dirname $0)
cd ${BASEDIR}/../../../../../../../ocr/bin

export WINEDEBUG=-all
wine ReadIRISOCRConverter.exe ${tmpDir} "$@"

rm -Rf ${tmpDir}
