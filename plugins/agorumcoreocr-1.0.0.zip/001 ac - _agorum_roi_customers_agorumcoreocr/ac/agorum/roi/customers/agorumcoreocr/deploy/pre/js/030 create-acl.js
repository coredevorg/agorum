/* global Packages, sc */

let objects = require('common/objects');

let path =  'agorumcoreocr';
let name = 'agorum core ocr';
let acl = objects.tryFind('acl:' + 'ACL_' + name);
if (!acl) {
  acl = objects.create('acl', {
    name: 'ACL_' + name,
    path: path,
  });
}
acl;