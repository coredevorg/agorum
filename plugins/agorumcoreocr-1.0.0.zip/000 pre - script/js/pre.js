let objects = require('common/objects');
if (objects.tryFind('/agorum/roi/customers/Standard/js/package/pre.js')) {
  require('/agorum/roi/customers/Standard/js/package/pre');
}